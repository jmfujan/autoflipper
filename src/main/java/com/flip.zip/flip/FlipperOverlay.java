package com.flip;

import net.runelite.api.Client;
import net.runelite.client.game.ItemManager;
import net.runelite.client.ui.overlay.Overlay;
import net.runelite.client.ui.overlay.OverlayPosition;
import net.runelite.client.ui.overlay.components.LineComponent;
import net.runelite.client.ui.overlay.components.PanelComponent;

import javax.inject.Inject;
import java.awt.*;
import java.util.List;
import java.util.Map;

public class FlipperOverlay extends Overlay {
    private final PanelComponent panelComponent = new PanelComponent();
    private final Client client;
    private final ItemManager itemManager;
    private final ExamplePlugin plugin;

    @Inject
    public FlipperOverlay(Client client, ItemManager itemManager, ExamplePlugin plugin) {
        this.client = client;
        this.itemManager = itemManager;
        this.plugin = plugin;

        setPosition(OverlayPosition.TOP_LEFT);
    }

    @Override
    public Dimension render(Graphics2D graphics) {
        panelComponent.getChildren().clear();

        panelComponent.getChildren().add(LineComponent.builder()
                .left("Test Overlay")
                .right("It works!")
                .build());

        return panelComponent.render(graphics);
    }
}